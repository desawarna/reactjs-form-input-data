import React, { Component } from 'react';

export default class Footer extends Component {
  render() {
    return (
      <div className="App">
        <footer>
          <p>Hai Ini Bagian Footer</p>
        </footer>
      </div>
    );
  }
}
